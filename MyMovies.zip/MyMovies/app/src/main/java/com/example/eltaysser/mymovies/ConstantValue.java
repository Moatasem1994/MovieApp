package com.example.eltaysser.mymovies;

  class ConstantValue {
    // create this class for static values , as you show in review
    static final String pathForImage = "https://image.tmdb.org/t/p/w500/";
    static final String urlPopular="https://api.themoviedb.org/3/movie/popular?api_key=092042c5d3956048aa1d5341d1571bdf&language=en-US&page";
    static final String urlVote="https://api.themoviedb.org/3/movie/top_rated?api_key=092042c5d3956048aa1d5341d1571bdf&language=en-US&page=1";
    static final String url = "https://api.themoviedb.org/3/discover/movie?primary_release_date.lte=2010&primary_release_year=2010&page=1&include_video=false&include_adult=false&language=en-US&api_key=092042c5d3956048aa1d5341d1571bdf";


}
